local utils = require('utils')
utils.map('n', '<Leader>gs', '<cmd>Gstatus<CR>')  -- Git status

