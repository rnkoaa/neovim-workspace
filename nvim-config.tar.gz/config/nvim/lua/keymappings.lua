local utils = require('utils')
-- utils.map('n', '<C-l>', '<cmd>noh<CR>') -- Clear highlights
utils.map('i', 'jk', '<Esc>')           -- jk to escape

-- nvimtree
utils.map('n', '<C-n>', '<cmd>NvimTreeToggle<CR>')           -- jk to escape
utils.map('n', '<leader>n', '<cmd>NvimTreeFindFile<CR>')           -- jk to escape
utils.map('n', '<leader>r', '<cmd>NvimTreeRefresh<CR>')           -- jk to escape
-- nnoremap <C-n> :NvimTreeToggle<CR>
-- nnoremap <leader>r :NvimTreeRefresh<CR>
-- nnoremap <leader>n :NvimTreeFindFile<CR>
-- " NvimTreeOpen and NvimTreeClose are also available if you need them

-- set termguicolors " this variable must be enabled for colors to be applied properly

-- " a list of groups can be found at `:help nvim_tree_highlight`
-- highlight NvimTreeFolderIcon guibg=blue
--
-- " Find files using Telescope command-line sugar.
utils.map('n', '<leader>tf', '<cmd>Telescope find_files<CR>')           
utils.map('n', '<leader>fg', '<cmd>Telescope live_grep<CR>')           
utils.map('n', '<leader>fb', '<cmd>Telescope buffers<CR>')           
utils.map('n', '<leader>fh', '<cmd>Telescope help_tags<CR>')        
utils.map('n', '<leader>fl', '<cmd>Telescope git_files<CR>')       

