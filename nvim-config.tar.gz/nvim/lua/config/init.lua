-- lspkind-nvim
require('config.lspkind')
require('config.nvimtree')
require('config.compe_config')
require('config.treesitter')
require('config.colorschemes')
require('config.fugitive')
require('config.gopls')
